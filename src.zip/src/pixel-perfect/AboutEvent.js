import React from 'react'

function AboutEvent() {
    return (
        <div className="about-event-container w-full max-w-4xl mx-auto p-6 mt-12 ">
            <div className='text-center text-6xl font-extrabold  font-Dancing'>
                <h1>About Picture Perfect</h1>
            </div>
            <div></div>
        </div>
    )
}

export default AboutEvent
