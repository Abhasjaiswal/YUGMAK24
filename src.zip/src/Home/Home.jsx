import React from 'react';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import Landing from '../Persona/Landing/Landing';
import Events from '../Persona/Events/Events';
import Participate from '../Persona/Participate/Participate';
import Video from '../Persona/VideoPart/Video';
import FAQ from '../Persona/FAQ/Faq';
const Home = () => {
  return (
    <div>
      <div><Landing /></div>
<div><Participate /></div>
      <div><Events /></div>
      <div><Video /></div>
      <div><FAQ /></div>
    </div>
  );
};

export default Home;
