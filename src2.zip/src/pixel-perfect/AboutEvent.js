import React from 'react'

function AboutEvent() {
    return (
        <div className=" w-full max-w-4xl mx-auto p-6  ">
            <div className='text-center md:text-6xl md:font-extrabold text-4xl font-bold '>
                <h1>About  Drishय
                </h1>

            </div>
            <div className='m-6 md:m-12 lg:m-16'>
    <div className='w-full md:w-[50vw] h-auto md:h-[40vh] backdrop-blur-md bg-white/30 shadow-lg shadow-[#F299A0] rounded-3xl p-4'>
        <p> </p>
    </div>
</div>

        </div>
    )
}

export default AboutEvent
