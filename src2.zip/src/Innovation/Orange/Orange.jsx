import React from 'react';
// import './Orange.css'; 
import orange from '../Landing/orange.png'
const Orange = () => {
    return (
        
      <div className='Orange'>
        <img src={orange} alt="Orange" />
      </div>
    );
};

export default Orange;