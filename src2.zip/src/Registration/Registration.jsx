import { BrowserRouter, Route, Routes } from 'react-router-dom';
import Page1 from './Page1/Page1';

function App() {
  
  return (
    <div className="App">
      
        <BrowserRouter>
          <Routes>
            <Route path='/page1' element={<Page1 />} />
          </Routes>
        </BrowserRouter>
      
    </div>
  );

}

export default App;
