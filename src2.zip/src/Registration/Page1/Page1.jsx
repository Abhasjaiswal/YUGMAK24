import React, { useState } from 'react';
import '../style.css';
import logo from '../bg.png';

const RegistrationAndEventSelection = () => {
    const [teamName, setTeamName] = useState('');
    const [leaderName, setLeaderName] = useState('');
    const [email, setEmail] = useState('');
    const [rollNo, setRollNo] = useState('');
    const [degree, setDegree] = useState('');
    const [year, setYear] = useState('');
    const [phoneNumber, setPhoneNumber] = useState('');
    const [altPhoneNumber, setAltPhoneNumber] = useState('');
    const [strength, setStrength] = useState('');
    const [selectedEvents, setSelectedEvents] = useState([]);
    const [showPage2, setShowPage2] = useState(false);

    const events = [
        { name: 'Hackathon', cost: 200 },
        { name: 'Startup Pitch', cost: 300 },
        { name: 'Coding Contest', cost: 150 },
        { name: 'Workshop', cost: 100 },
    ];

    const handleNext = () => {
        // Validate all fields in Page 1
        if (!teamName || !leaderName || !email || !rollNo || !degree || !year || !phoneNumber || !altPhoneNumber || !strength || selectedEvents.length === 0) {
            alert("Please fill out all the fields and select at least one event before proceeding.");
            return;
        }
        // If validation passes, show Page 2
        setShowPage2(true);
    };

    const handleEventChange = (event, cost) => {
        if (selectedEvents.some(e => e.name === event)) {
            setSelectedEvents(selectedEvents.filter(e => e.name !== event));
        } else {
            setSelectedEvents([...selectedEvents, { name: event, cost }]);
        }
    };

    // Page 2 State and Functions
    const [formData, setFormData] = useState(
        Array.from({ length: 4 }, () => ({
            name: '',
            sapid: '',
            rollNo: '',
            year: '',
            degree: '',
            field: '',
            email: '',
        }))
    );

    const handleChange = (index, field, value) => {
        const newFormData = [...formData];
        newFormData[index][field] = value;
        setFormData(newFormData);
    };

    const handleSubmit = () => {
        const allFieldsFilled = formData.slice(0, parseInt(strength) - 1).every(member =>
            Object.values(member).every(value => value !== '')
        );
        if (allFieldsFilled) {
            alert('Form Submitted Successfully!');
            // Handle form submission here (e.g., send to backend, etc.)
        } else {
            alert('Please fill out all fields.');
        }
    };

    const handlePrevious = () => {
        setShowPage2(false);
    };

    return (
        <div className="container">
            <header>
                <a href="/" className="back-link">Back to homepage</a>
                <img src={logo} alt="Logo" className="logo" />
                <img src="random_logo_right.png" alt="Logo Right" className="logo-right" />
            </header>

            {!showPage2 ? (
                <div className="form-container">
                    <div className="form-steps">
                        <div className="step active">1. Team Lead details</div>
                        <div className="step">2. Member Details</div>
                        <div className="step">3. Payment</div>
                    </div>

                    {/* Team details form */}
                    <div style={{ textAlign: 'center' }}>
                        <h2 className='hd'>Team Details</h2>
                    </div>
                    
                    <form>
                        <div className="form-row">
                            <label htmlFor="teamName">Team Name</label>
                            <input
                                type="text"
                                id="teamName"
                                name="teamName"
                                placeholder="Team Name"
                                value={teamName}
                                onChange={(e) => setTeamName(e.target.value)}
                                required
                            />
                        </div>
                        <div className="form-row">
                            <label htmlFor="leaderName">Leader's Name</label>
                            <input
                                type="text"
                                id="leaderName"
                                name="leaderName"
                                placeholder="Name of the Team Leader"
                                value={leaderName}
                                onChange={(e) => setLeaderName(e.target.value)}
                                required
                            />
                        </div>
                        <div className="form-row">
                            <label htmlFor="email">E-mail</label>
                            <input
                                type="email"
                                id="email"
                                name="email"
                                placeholder="Personal E-Mail of the Team Leader"
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                                required
                            />
                        </div>
                        <div className="form-row">
                            <label htmlFor="rollNo">Roll no.</label>
                            <input
                                type="text"
                                id="rollNo"
                                name="rollNo"
                                placeholder="Of the Team Leader"
                                value={rollNo}
                                onChange={(e) => setRollNo(e.target.value)}
                                required
                            />
                        </div>
                        <div className="form-row">
                            <label htmlFor="degree">Degree</label>
                            <select
                                id="degree"
                                name="degree"
                                value={degree}
                                onChange={(e) => setDegree(e.target.value)}
                                required
                            >
                                <option value="">Select Degree</option>
                                <option value="btech">B.Tech</option>
                                <option value="mtech">M.Tech</option>
                                <option value="phd">PhD</option>
                            </select>
                        </div>
                        <div className="form-row">
                            <label htmlFor="year">Year of Study</label>
                            <select
                                id="year"
                                name="year"
                                value={year}
                                onChange={(e) => setYear(e.target.value)}
                                required
                            >
                                <option value="">Select Year</option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                            </select>
                        </div>
                        <div className="form-row">
                            <label htmlFor="phoneNumber">Phone number</label>
                            <input
                                type="text"
                                id="phoneNumber"
                                name="phoneNumber"
                                placeholder="Of the Team Leader"
                                value={phoneNumber}
                                onChange={(e) => setPhoneNumber(e.target.value)}
                                required
                            />
                        </div>
                        <div className="form-row">
                            <label htmlFor="altPhoneNumber">Alternate Phone number</label>
                            <input
                                type="text"
                                id="altPhoneNumber"
                                name="altPhoneNumber"
                                placeholder="Of the Team Leader"
                                value={altPhoneNumber}
                                onChange={(e) => setAltPhoneNumber(e.target.value)}
                                required
                            />
                        </div>
                        <div className="form-row">
                            <label htmlFor="strength">Strength of the team</label>
                            <div className="radio-group">
                                <label>
                                    <input
                                        type="radio"
                                        name="strength"
                                        value="2"
                                        onChange={() => setStrength("2")}
                                        checked={strength === "2"}
                                        required
                                    />
                                    <span> 2</span>
                                </label>
                                <label>
                                    <input
                                        type="radio"
                                        name="strength"
                                        value="3"
                                        onChange={() => setStrength("3")}
                                        checked={strength === "3"}
                                        required
                                    />
                                    <span> 3 </span>
                                </label>
                                <label>
                                    <input
                                        type="radio"
                                        name="strength"
                                        value="4"
                                        onChange={() => setStrength("4")}
                                        checked={strength === "4"}
                                        required
                                    />
                                    <span> 4 </span>
                                </label>
                            </div>
                        </div>
                    </form>
                    
                    <div className="events-list1">
                        <h2 className='hd'>Select Events</h2>
                        <p style={{fontSize:'1.2rem',paddingBottom:'4vh'}}>Please select the events you want to participate in:</p>
                        <div className='ev-list'>
                            {events.map((event, index) => (
                                <div key={index} className="event-item">
                                    <input
                                        type="checkbox"
                                        id={`event_${index}`}
                                        onChange={() => handleEventChange(event.name, event.cost)}
                                        required
                                    />
                                    <label className='lbl' htmlFor={`event_${index}`}>
                                        {event.name} - ₹{event.cost}
                                    </label>
                                </div>
                            ))}
                        </div>
                        <div className="actions-container">
                            <button type="button" className="next-btn" onClick={handleNext}>Next</button>
                        </div>
                    </div>
                </div>
            ) : (
                <div className="form-container">
                    <div className="form-steps">
                        <div className="step">1. Team details</div>
                        <div className="step">2. Select Events</div>
                        <div className="step active">3. Submit</div>
                    </div>

                    {/* Page 2 content */}
                    <div style={{ textAlign: 'center' }}>
                        <h2 className='hd'>Additional Team Members Details</h2>
                    </div>

                    <form>
                        {formData.slice(0, parseInt(strength) - 1).map((member, index) => (
                            <div key={index} className="form-row">
                                <h5 className='hd'>Member {index + 1} Details</h5>
                                <label htmlFor={`name_${index}`}>Name</label>
                                <input
                                    type="text"
                                    id={`name_${index}`}
                                    name={`name_${index}`}
                                    placeholder="Name of Member"
                                    value={member.name}
                                    onChange={(e) => handleChange(index, 'name', e.target.value)}
                                    required
                                />
                                <label htmlFor={`sapid_${index}`}>SAP ID</label>
                                <input
                                    type="text"
                                    id={`sapid_${index}`}
                                    name={`sapid_${index}`}
                                    placeholder="SAP ID"
                                    value={member.sapid}
                                    onChange={(e) => handleChange(index, 'sapid', e.target.value)}
                                    required
                                />
                                <label htmlFor={`rollNo_${index}`}>Roll no.</label>
                                <input
                                    type="text"
                                    id={`rollNo_${index}`}
                                    name={`rollNo_${index}`}
                                    placeholder="Roll No."
                                    value={member.rollNo}
                                    onChange={(e) => handleChange(index, 'rollNo', e.target.value)}
                                    required
                                />
                                <label htmlFor={`year_${index}`}>Year of study</label>
                                <input
                                    type="text"
                                    id={`year_${index}`}
                                    name={`year_${index}`}
                                    placeholder="Year of Study"
                                    value={member.year}
                                    onChange={(e) => handleChange(index, 'year', e.target.value)}
                                    required
                                />
                                <label htmlFor={`degree_${index}`}>Degree</label>
                                <input
                                    type="text"
                                    id={`degree_${index}`}
                                    name={`degree_${index}`}
                                    placeholder="Degree"
                                    value={member.degree}
                                    onChange={(e) => handleChange(index, 'degree', e.target.value)}
                                    required
                                />
                                <label htmlFor={`field_${index}`}>Field</label>
                                <input
                                    type="text"
                                    id={`field_${index}`}
                                    name={`field_${index}`}
                                    placeholder="Field of Study"
                                    value={member.field}
                                    onChange={(e) => handleChange(index, 'field', e.target.value)}
                                    required
                                />
                                <label htmlFor={`email_${index}`}>Email ID</label>
                                <input
                                    type="email"
                                    id={`email_${index}`}
                                    name={`email_${index}`}
                                    placeholder="Email ID"
                                    value={member.email}
                                    onChange={(e) => handleChange(index, 'email', e.target.value)}
                                    required
                                />
                            </div>
                        ))}
                    </form>
                    <div className="actions-container">
                        <button type="button" className="prev-btn" onClick={handlePrevious}>Previous</button>
                        <button type="button" className="submit-btn" onClick={handleSubmit}>Submit</button>
                    </div>
                </div>
            )}
        </div>
    );
};

export default RegistrationAndEventSelection;